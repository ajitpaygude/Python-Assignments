def add():
    print("Enter 2 nos:\n");
    no1=int(input());
    no2=int(input());
    print("Addition of 2 nos:", no1+no2);

def main():
    add();

if(__name__=='__main__'):
    main();