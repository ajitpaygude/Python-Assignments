def display():
    i=5;
    while(i!=0):
        print("Marvellous");
        i=i-1;


display();
