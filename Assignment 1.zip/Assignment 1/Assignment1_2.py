def ChkNum(no):
    if(no%2==0):
        print(no,"Number is Even");
    else:
        print(no,"Number is odd");

def main():
    print("Please enter number to check:");
    no=int(input());
    ChkNum(no);

if(__name__=='__main__'):
    main();

