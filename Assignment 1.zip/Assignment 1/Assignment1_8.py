def display():
    print("Enter number");
    no=int(input());

    while(no!=0):
        print("*", end=" ");
        no=no-1;

display();