def fun():
    print("Enter number to check");
    no=int(input());
    if(no%5==0):
        return True;
    else:
        return False;

print("Number divisible by 5?",fun());