def accept():
    print("Enter number to check");
    no=int(input());
    if(no>0):
        print("Number is positive");
    elif(no<0):
        print("Number is negative");
    else:
        print("Zero");

accept();