def length():
    cnt=0;
    print("Enter name:");
    name=input();
    for i in name:
       cnt=cnt+1;
    print(" length", cnt);
    #print(len(name));

length();