class Arithmetic:

    def __init__(self):
        self.no1=0;
        self.no2=0;

    def accpet(self):
        self.no1=int(input("Enter first number:"));
        self.no2= int(input("Enter second number:"));

    def Addtion(self):
        return self.no1+self.no2;

    def Subtraction(self):
        return self.no1-self.no2;

    def Multiplication(self):
        return self.no1*self.no2;

    def Division(self):
        return self.no1//self.no2;

def main():
    obj=Arithmetic();
    obj.accpet();
    print("Addition is:",obj.Addtion());
    print("Subtraction is:", obj.Subtraction());
    print("Multiplication is:", obj.Multiplication());
    print("Division is:", obj.Division());

if(__name__=='__main__'):
    main();