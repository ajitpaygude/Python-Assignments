class circle:
    pi=3.142;

    def __init__(self):
        self.radius=0.0;
        self.area=0.0;
        self.circumference=0.0;

    def accpet(self):
        self.radius=float(input("Enter radius:"));

    def calculateArea(self):
        self.area= float(circle.pi*self.radius*self.radius);

    def calculateCircumference(self):
        self.circumference=float(2*circle.pi*self.radius);

    def display(self):
        print("Radius:", self.radius);
        print("Area of circle:",self.area);
        print("Circumference of circle:", self.circumference);

def main():
    obj=circle();
    obj.accpet();
    obj.calculateArea();
    obj.calculateCircumference();
    obj.display();

if(__name__=='__main__'):
    main();

