class Demo:
    value=5;

    def __init__(self,a,b):
        self.no1=a;
        self.no2=b;

    def fun(self):
        print("Inside fun:")
        print("No1---",self.no1);
        print("No2---", self.no2);

    def gun(self):
        print("Inside gun:")
        print("No1---", self.no1);
        print("No2---", self.no2);

def main():
     no1,no2=input("Enter two numbers for object1:").split(',');
     obj1=Demo(int(no1),int(no2));
     no1, no2 =input("Enter two numbers for object2:").split(',');
     obj2=Demo(int(no1),int(no2));
     obj1.fun();
     obj1.gun();
     obj2.fun();
     obj2.gun();
     Demo.sun();

if(__name__=='__main__'):
    main();