def main():
    no1,no2=int(input("Please enter two numbers:")),int(input());
    ans=lambda no1,no2:no1*no2;
    print("Multiplication of two numbers:",ans(no1,no2));

if(__name__=='__main__'):
    main();