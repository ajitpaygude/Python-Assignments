def main():
    no=int(input("Please enter number:"));
    pow=lambda no: 2**no;
    print("Power of 2:",pow(no));

if(__name__=='__main__'):
    main();