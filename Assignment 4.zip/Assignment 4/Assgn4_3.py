from functools import reduce;
def main():
    n=int(input("How many elements:"));
    a=list();
    for i in range(0,n):
        print("Enter element:",i+1);
        a.append(int(input()));

    filterList=list(filter(lambda no:no>=70 and no<=90,a));
    mapList=list(map(lambda no:no+10,filterList));
    output=reduce(lambda no1,no2:no1*no2,mapList);

    print("Final output:",output);

if(__name__=='__main__'):
    main();