def chkPrime(no):
    f=1;
    if(no>1):
        for i in range(2,no//2+1):
            if(no%i==0):
               f=0;
        if(f==0):
          return 0;
        else:
          return no;
    else:
        return 0;