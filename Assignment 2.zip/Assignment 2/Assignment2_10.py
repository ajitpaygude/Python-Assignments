def addDigit():
    print("Enter number:");
    no=int(input());
    sum=0;
    while(no>0):
        sum=sum+no%10;
        no=int(no/10);
    print("Addition of digits of number", sum);

addDigit();