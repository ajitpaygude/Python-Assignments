from Arithmetic import *;

def main():
    print("Enter 2 nos:");
    no1=int(input());
    no2=int(input());
    print("Addition is:", add(no1,no2));
    print("Subtraction is:", sub(no1, no2));
    print("Multiplication is:", mul(no1, no2));
    print("Division is:", div(no1, no2));

main();