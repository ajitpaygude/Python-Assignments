def factor():
    print("Enter no:");
    no=int(input());
    f=0;
    for i in range(1,no):
        if(no%i==0):
            f=f+i;
    print("Addition of factor is:",f);

factor();