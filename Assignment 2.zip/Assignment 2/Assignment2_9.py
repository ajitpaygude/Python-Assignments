def count():
    print("Enter number:");
    no=int(input());
    cnt=0;
    while(no>0):
        cnt=cnt+1;
        no=int(no/10);
    print("Number of digits:", cnt);

count();