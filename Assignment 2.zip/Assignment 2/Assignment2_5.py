def prime():
    print("Enter number to check");
    no=int(input());
    flag=0;
    if(no>1):
      for i in range(2,no):
         if(no%i==0):
            flag=1;
            break;
      if(flag==1):
        print("Number is not prime");
      else:
        print("Number is prime");
    else:
        print("Number is not prime");

prime();