def pattern():
    print("Enter number:");
    no=int(input());
    for i in range(no,0,-1):
        for j in range(1,i+1):
           print("*", end=" ");
        print(" ");


pattern();