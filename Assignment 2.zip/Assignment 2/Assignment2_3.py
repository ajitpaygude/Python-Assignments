def factorial():
    print("Enter no");
    no=int(input());
    f=1;
    for i in range(1,no+1):
        f=f*i;
    print("Factorial:", f);

factorial();