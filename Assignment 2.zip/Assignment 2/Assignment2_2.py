def display():
    print("Enter no:");
    no=int(input());
    for i in range(1,no+1):
        for j in range(1,no+1):
            print("*", end=" ");
        print(" ");

display();