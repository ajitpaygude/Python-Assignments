def main(no):

    if(no>0):
        print("*", end=" ");
        main(no-1);

if(__name__=='__main__'):
    no = int(input("Enter element:"));
    main(no);