def main(no):
    if(no>0):
        main(no-1);
        print(no, end=" ");

if(__name__=='__main__'):
    no=int(input("Enter number:"));
    main(no);