def main(no):
    if(no>0):
        print(no, end=" ");
        main(no-1);

if(__name__=='__main__'):
    no=int(input("Enter number:"));
    main(no);