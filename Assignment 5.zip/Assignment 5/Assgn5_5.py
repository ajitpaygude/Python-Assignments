def main(no):
    if(no>0):
       return (no * main(no-1));
    else:
        return 1;

if(__name__=='__main__'):
    no=int(input("Please enter number:"));
    print("Factorial of number:",main(no));