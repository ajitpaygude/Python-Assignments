#s=0;
def main(no):
    #global s;
    if(no>0):
        #s=s+no%10;
        return (no%10 + main(no//10));
    else:
        return 0;

if(__name__=='__main__'):
    no=int(input("Enter number:"));
    #main(no);
    print("Sum of digits:", main(no));