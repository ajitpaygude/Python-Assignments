class Numbers:

    def __init__(self,val):
        self.value=val;

    def chkPrime(self):
        f=1;
        for i in range(2,self.value//2+1):
            if(self.value%i==0):
                f=0;
        if(f==0):
            print("Number is not prime");
        else:
            print("Number is prime");

    def chkPerfect(self):
        if(self.sumOfFactors()==self.value):
            print("Number is perfect");
        else:
            print("Number is not perfect");

    def factors(self):
        f=list();
        for i in range(1,self.value//2+1):
            if(self.value%i==0):
                f.append(i);
        print("Factors of number:",f);

    def sumOfFactors(self):
        s=0;
        for i in range(1,self.value//2+1):
            if (self.value % i == 0):
                s=s+i;
        return s;


def main():
    no=int(input("Enter number:"));
    obj=Numbers(no);
    obj.chkPrime();
    obj.factors();
    print("Sum of factors:",obj.sumOfFactors());
    obj.chkPerfect();

if(__name__=='__main__'):
    main();