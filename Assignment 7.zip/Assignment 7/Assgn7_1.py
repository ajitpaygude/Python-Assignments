class BookStore:
    NoOfBooks=0;

    def __init__(self,name,author):
        self.name=name;
        self.author=author;
        BookStore.NoOfBooks+=1;

    def display(self):
        print("Book name:",self.name);
        print("Author name:",self.author);
        print("Total books:",self.NoOfBooks);
        print("------------------------------------");

def main():
     obj1=BookStore("Linux system programming","Robert Love");
     obj1.display();
     obj2=BookStore("C Programming", "Dennis Ritchie");
     obj2.display();

if(__name__=='__main__'):
    main();