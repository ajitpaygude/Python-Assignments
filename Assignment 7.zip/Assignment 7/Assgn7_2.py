class BankAccount:
    ROI=10.5;

    def __init__(self,n,amt):
        self.name=n;
        self.amount=amt;

    def display(self):
        print("Customer name:",self.name);
        print("Amount in account:",self.amount);
        print("---------------------------------------");

    def deposit(self,amt):
        self.amount+=amt;

    def withdraw(self,amt):
        self.amount-=amt;

    def calculateIntrest(self):
        print("Intrest:",self.amount*BankAccount.ROI);

def main():
    name=input("Enter customer name:");
    amt=float(input("Enter amount:"));
    obj=BankAccount(name,amt);
    obj.display();
    obj.deposit(500);
    print("After deposit:");
    obj.display();
    obj.withdraw(500);
    print("After withdraw:");
    obj.display();

if(__name__=='__main__'):
    main();

