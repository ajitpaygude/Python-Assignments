from MarvellousNum import chkPrime;
def listPrime():
    n = int(input("How many elements u want?"));
    a = list();
    s=0;
    for i in range(0,n):
        print("Enter element ",i+1);
        a.append(int(input()));
        s=s+chkPrime(a[i]);
    print("Sum of all prime numbers from list: ",s);

def main():
    listPrime();

if(__name__=='__main__'):
    main();