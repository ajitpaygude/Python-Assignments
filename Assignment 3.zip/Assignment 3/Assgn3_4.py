def main():
    n=int(input("How many elements u want?"));
    a=list();
    c=0;
    for i in range(0,n):
        print("Enter element",i+1);
        a.append(int(input()));
    no=int(input("Enter element to search:"));
    for i in range(0,n):
        if(no==a[i]):
            c=c+1;
    if(c>0):
        print("Frequency of given number : ",c);
    else:
        print("Given number is not present in list");

if(__name__=='__main__'):
    main();