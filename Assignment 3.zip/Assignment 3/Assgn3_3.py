def main():
    n=int(input("How many elements? "));
    a=list();

    for i in range(0,n):
        print("Enter element",i+1);
        a.append(int(input()));
        if(i==0):
           min=a[0];
        elif(min>a[i]):
            min=a[i];
    print("Minimum number from list: ",min);
    #print("Minimum number from list: ", min(a));

if(__name__=='__main__'):
    main();