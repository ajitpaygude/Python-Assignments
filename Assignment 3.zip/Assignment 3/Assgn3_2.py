def main():
    n=int(input("How many elements u want?"));
    max=0;
    a=list();
    for i in range(0,n):
        print("Enter element",i+1);
        a.append(int(input()));
        if(a[i]>max):
            max=a[i];
    print("Maximum number from list: ",max);
   # print("Maxmimun number from list: ",max(a));

if(__name__=='__main__'):
    main();