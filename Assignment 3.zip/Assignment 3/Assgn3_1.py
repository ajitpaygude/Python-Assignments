def main():
    n=int(input("How many elements u want?"));
    a=list();
    s=0;
    for i in range(0,n):
        print("Enter element",i+1);
        a.append(int(input()));
        s=s+a[i];
    print("Sum of all elements: ",s);

if(__name__=='__main__'):
    main();